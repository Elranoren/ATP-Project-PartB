package algorithms.mazeGenerators;

public class Maze {
    int rows , columns;
    Position start,end;
    int[][] maze;

    /**
     * @param rows Maze rows
     * @param columns Maze columns
     */
    public Maze(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        maze = new int[rows][columns];

        }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public int[][] getMaze() {
        return maze;
    }

    public void setMaze(int[][] maze) {
        this.maze = maze;
    }

    public Position getStartPosition() {
        return this.start;
    }

    public Position getGoalPosition() {
        return this.end;
    }

    public void setStartPosition(Position p) {
        this.start = p;
    }

    public void setGoalPosition(Position p) {
        this.end = p;
    }

    public void Print() {

    }

}

