package algorithms.mazeGenerators;

public class mazeGenerators extends AMazeGenerator{
    @Override
    public Maze generate(int rows, int columns) {
        return null;
    }
}
